package com.Inventory.Inventory.user;

public enum UserRole {
    ADMIN, MANAGER
}

