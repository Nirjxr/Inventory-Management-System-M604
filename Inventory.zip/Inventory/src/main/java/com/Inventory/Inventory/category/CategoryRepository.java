package com.Inventory.Inventory.category;

import com.Inventory.Inventory.core.BaseRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface CategoryRepository extends BaseRepository<Category, Long> {
}
